//  ███████████    █████████  ███████████ ████                               ████████  ██████████
// ░░███░░░░░███  ███░░░░░███░░███░░░░░░█░░███                              ███░░░░███░░███░░░░███
//  ░███    ░███ ███     ░░░  ░███   █ ░  ░███   ██████  █████ ███ █████   ░░░    ░███ ░███   ░░███
//  ░██████████ ░███          ░███████    ░███  ███░░███░░███ ░███░░███       ██████░  ░███    ░███
//  ░███░░░░░░  ░███    █████ ░███░░░█    ░███ ░███ ░███ ░███ ░███ ░███      ░░░░░░███ ░███    ░███
//  ░███        ░░███  ░░███  ░███  ░     ░███ ░███ ░███ ░░███████████      ███   ░███ ░███    ███
//  █████        ░░█████████  █████       █████░░██████   ░░████░████      ░░████████  ██████████
// ░░░░░          ░░░░░░░░░  ░░░░░       ░░░░░  ░░░░░░     ░░░░ ░░░░        ░░░░░░░░  ░░░░░░░░░░

// =========================================================================
//  Copyright (C) 2024-2024 Technical University of Munich, ENAC - Ecole Nationale de l'Aviation Civile
//  This file is part of PGFlow3D.

//  Permission is hereby granted, free of charge, to any person
//  obtaining a copy of this software and associated documentation
//  files (the "Software"), to deal in the Software without
//  restriction, including without limitation the rights to use,
//  copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following
//  conditions:

//  The above copyright notice and this permission notice shall be
//  included in all copies or substantial portions of the Software.

//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//  OTHER DEALINGS IN THE SOFTWARE.

//  Authors:
//           M Kuersat Yurt, MSc. (TUM)
// =========================================================================

#ifndef CASE_HPP
#define CASE_HPP

#include <boost/geometry.hpp>
#include <boost/geometry/geometries/register/point.hpp>
#include "building.hpp"
#include "goal.hpp"
#include "vehicle.hpp"

namespace bg  = boost::geometry;
namespace bgi = boost::geometry::index;
// Define Eigen::Vector3d as a 3D point type
BOOST_GEOMETRY_REGISTER_POINT_3D(Eigen::Vector3d, double, bg::cs::cartesian, data()[0], data()[1], data()[2])

class Case {
private:
  typedef bg::model::box<Eigen::Vector3d>                                Box;
  typedef bg::model::polygon<Eigen::Vector3d>                            Poly;
  typedef bgi::rtree<std::pair<Eigen::Vector3d, size_t>, bgi::rstar<16>> VehicleRTree;
  typedef bgi::rtree<std::pair<Box, size_t>, bgi::rstar<16>>             BuildingRTree;

  std::vector<Vehicle>  _vehicles;
  std::vector<Goal>     _goals;
  std::vector<Building> _buildings;
  Eigen::Vector3d       _freestream;
  double                _goalReachDistance{0.1};
  BuildingRTree         _buildingRtree;
  std::vector<Box>      _buildingBoxes;
  VehicleRTree          _vehicleRtree;
  bool                  _thisRoundHasVehicleRtree{false};
  std::vector<double>   _nearestBuildingDistance;

public:
  void addVehicle();
  void addGoal();
  void addBuilding();

  Vehicle  &getVehicle(size_t index);
  Goal     &getGoal(size_t index);
  Building &getBuilding(size_t index);

  void setVehiclePosition(size_t index, const Eigen::Vector3d &position);
  void setVehicleVelocity(size_t index, const Eigen::Vector3d &velocity);
  void setVehicleSourceStrength(size_t index, double sourceStrength);
  void setVehiclePriority(size_t index, const double priority);

  Eigen::Vector3d getVehiclePosition(size_t index);
  Eigen::Vector3d getVehicleVelocity(size_t index);

  void            setGoalPosition(size_t index, const Eigen::Vector3d &position);
  void            setGoalStrength(size_t index, double strength);
  Eigen::Vector3d getGoalPosition(size_t index);

  void   initBuildingFromOBJFile(size_t index, const std::string &filename);
  void   translateBuilding(size_t index, const Eigen::Vector3d &translation);
  void   rotateBuilding(size_t index, const double q0, const double q1, const double q2, const double q3);
  void   dumpBuildingToVTK(size_t index, const std::string &file);
  double getBuildingSafetyVelocity(size_t index);
  void   setBuildingSafetyVelocity(size_t index, double safetyVelocity);

  void                          setFreeStream(const Eigen::Vector3d &freestream);
  [[nodiscard]] Eigen::Vector3d getFreeStream() const;

  [[nodiscard]] size_t getNumberOfVehicles() const;
  [[nodiscard]] size_t getNumberOfBuildings() const;

  void calculateVehicleVelocities(const double);
  void calculateVehicleVelocitiesWithGuidanceStream(const double, const double);
  void calculateVehicleVelocitiesWithGuidanceStreamAdaptively(const double, const double, const double, const double);
  void advanceVehicles(double dt);

  void                 setGoalReachDistance(double goalReachDistance);
  [[nodiscard]] double getGoalReachDistance() const;
  bool                 isGoalReached(size_t index);

  void                createVehicleRtree();
  std::vector<size_t> findNearbyVehicles(const size_t index, const double radius);

  void                createBuildingRtree();
  std::vector<size_t> findNearbyBuildings(const size_t index, const double radius);

  double getNearestBuildingDistance(const size_t);
  double getGoalDistance(const size_t);
};
#endif // CASE_HPP