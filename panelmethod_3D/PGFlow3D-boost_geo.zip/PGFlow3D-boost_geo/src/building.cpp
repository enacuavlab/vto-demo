//  ███████████    █████████  ███████████ ████                               ████████  ██████████
// ░░███░░░░░███  ███░░░░░███░░███░░░░░░█░░███                              ███░░░░███░░███░░░░███
//  ░███    ░███ ███     ░░░  ░███   █ ░  ░███   ██████  █████ ███ █████   ░░░    ░███ ░███   ░░███
//  ░██████████ ░███          ░███████    ░███  ███░░███░░███ ░███░░███       ██████░  ░███    ░███
//  ░███░░░░░░  ░███    █████ ░███░░░█    ░███ ░███ ░███ ░███ ░███ ░███      ░░░░░░███ ░███    ░███
//  ░███        ░░███  ░░███  ░███  ░     ░███ ░███ ░███ ░░███████████      ███   ░███ ░███    ███
//  █████        ░░█████████  █████       █████░░██████   ░░████░████      ░░████████  ██████████
// ░░░░░          ░░░░░░░░░  ░░░░░       ░░░░░  ░░░░░░     ░░░░ ░░░░        ░░░░░░░░  ░░░░░░░░░░

// =========================================================================
//  Copyright (C) 2024-2024 Technical University of Munich, ENAC - Ecole Nationale de l'Aviation Civile
//  This file is part of PGFlow3D.

//  Permission is hereby granted, free of charge, to any person
//  obtaining a copy of this software and associated documentation
//  files (the "Software"), to deal in the Software without
//  restriction, including without limitation the rights to use,
//  copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following
//  conditions:

//  The above copyright notice and this permission notice shall be
//  included in all copies or substantial portions of the Software.

//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//  OTHER DEALINGS IN THE SOFTWARE.

//  Authors:
//           M Kuersat Yurt, MSc. (TUM)
// =========================================================================

#include "building.hpp"
#include <Eigen/Geometry>
#include <chrono>
#include <filesystem>
#include <iostream>
#include "rapidobj/rapidobj.hpp"

Eigen::Vector3d Building::transformVectorToInertialFrame(Eigen::Vector3d vectorInLocalFrame, size_t panelId)
{
  Eigen::Vector3d vectorInInertialFrame;

  vectorInInertialFrame(0) = (vectorInLocalFrame(0) * _cellOblique[panelId](0) + vectorInLocalFrame(1) * _cellTangent[panelId](0) + vectorInLocalFrame(2) * _cellNormals[panelId](0));
  vectorInInertialFrame(1) = (vectorInLocalFrame(0) * _cellOblique[panelId](1) + vectorInLocalFrame(1) * _cellTangent[panelId](1) + vectorInLocalFrame(2) * _cellNormals[panelId](1));
  vectorInInertialFrame(2) = (vectorInLocalFrame(0) * _cellOblique[panelId](2) + vectorInLocalFrame(1) * _cellTangent[panelId](2) + vectorInLocalFrame(2) * _cellNormals[panelId](2));
  return vectorInInertialFrame;
}

Eigen::Vector3d Building::transformPointToPanelLocalFrame(const Eigen::Vector3d &pointInInertialFrame, size_t panelId)
{
  Eigen::Vector3d pointInLocalFrame;
  auto            Diff = pointInInertialFrame - _cellCenters[panelId];
  pointInLocalFrame(0) = Diff.dot(_cellOblique[panelId]);
  pointInLocalFrame(1) = Diff.dot(_cellTangent[panelId]);
  pointInLocalFrame(2) = Diff.dot(_cellNormals[panelId]);
  return pointInLocalFrame;
}

Eigen::Vector3d Building::calculateVelocityDueToSinglePanel(Eigen::Vector3d point, size_t panelId)
{
  Eigen::Vector3d velocityAtPoint{0, 0, 0};
  // Iterate over each edge of the triangular panel
  bool all_inside{true};

  // Get the coordinates of the three nodes and point in panel frame
  Eigen::Vector3d              point_coo = transformPointToPanelLocalFrame(point, panelId);
  std::vector<Eigen::Vector3d> panel_coo(3);
  for (size_t i = 0; i < 3; i++) {
    panel_coo[i] = transformPointToPanelLocalFrame(_vertices[_connectivity[panelId](i)], panelId);
  }

  for (size_t i = 0; i < 3; i++) {
    // Define the indices of the two nodes that make the edge
    size_t j = (i + 1) % 3;
    // Get the coordinates of the two nodes in panel frame
    const double xi = panel_coo[i](0);
    const double yi = panel_coo[i](1);
    const double xj = panel_coo[j](0);
    const double yj = panel_coo[j](1);

    //  Calculate the terms needed for the velocity components
    const double d_ij   = std::sqrt((yj - yi) * (yj - yi) + (xj - xi) * (xj - xi));
    const double S_ij   = (yj - yi) / d_ij;
    const double C_ij   = (xj - xi) / d_ij;
    const double s_ij_i = (xi - point_coo(0)) * C_ij + (yi - point_coo(1)) * S_ij;
    const double s_ij_j = (xj - point_coo(0)) * C_ij + (yj - point_coo(1)) * S_ij;
    const double R_ij   = (point_coo(0) - xi) * S_ij - (point_coo(1) - yi) * C_ij;
    const double r_i    = std::sqrt((point_coo(0) - xi) * (point_coo(0) - xi) + (point_coo(1) - yi) * (point_coo(1) - yi) + (point_coo(2) * point_coo(2)));
    const double r_j    = std::sqrt((point_coo(0) - xj) * (point_coo(0) - xj) + (point_coo(1) - yj) * (point_coo(1) - yj) + (point_coo(2) * point_coo(2)));
    const double Q_ij   = std::log((r_i + r_j + d_ij) / (r_i + r_j - d_ij + 1e-14));
    all_inside          = all_inside && (R_ij > 0.0);

    const double J_ij = std::atan2(R_ij * std::abs(point_coo(2)) * (r_i * s_ij_j - r_j * s_ij_i), r_i * r_j * R_ij * R_ij + point_coo(2) * point_coo(2) * s_ij_j * s_ij_i);
    velocityAtPoint(0) -= S_ij * Q_ij;
    velocityAtPoint(1) += C_ij * Q_ij;
    velocityAtPoint(2) -= std::copysign(1.0, point_coo(2)) * J_ij;
  }
  if (all_inside && std::abs(point_coo(2)) < 1e-12) { // Very close to zero
    velocityAtPoint(2) += 2 * M_PI;
  } else if (all_inside) { // Inside panel but not close to zero
    velocityAtPoint(2) += std::copysign(1.0, point_coo(2)) * 2 * M_PI;
  }

  velocityAtPoint /= 4 * M_PI;

  // Transform the velocity to the inertial frame
  velocityAtPoint = transformVectorToInertialFrame(velocityAtPoint, panelId);
  return velocityAtPoint;
}

void Building::initFromOBJFile(const std::string &filename)
{
  // Check if the file exist or not
  if (!std::filesystem::exists(filename)) {
    throw std::runtime_error("File does not exist " + filename);
  }

  // Get the extension of the file
  std::filesystem::path pathOfFile(filename);
  std::string           extension = pathOfFile.extension().string();
  // Read the file based on the extension
  if (extension != ".obj") {
    throw std::runtime_error("File format not supported");
  }
  auto objFile = rapidobj::ParseFile(pathOfFile);

  if (objFile.error) {
    std::cout << objFile.error.code.message() << "\n";
    if (!objFile.error.line.empty()) {
      std::cout << "On line " << objFile.error.line_num << ": \"" << objFile.error.line << "\"\n";
    }
  }

  // Get the number of cells and points
  size_t nPoints = objFile.attributes.positions.size() / 3;

  auto nCells = size_t(0);
  for (const auto &shape : objFile.shapes) {
    nCells += shape.mesh.num_face_vertices.size();
  }

  // Resize the vectors
  _vertices.resize(nPoints);
  _connectivity.resize(nCells);
  _cellCenters.resize(nCells);
  _cellNormals.resize(nCells);
  _cellTangent.resize(nCells);
  _cellOblique.resize(nCells);
  _AICMatrix.resize(nCells, nCells);
  _AICMatrixInv.resize(nCells, nCells);
  _sigma.resize(nCells);

  // Get the points
  for (size_t i = 0; i < nPoints; i++) {
    _vertices[i] = Eigen::Vector3d(objFile.attributes.positions[3 * i], objFile.attributes.positions[3 * i + 1], objFile.attributes.positions[3 * i + 2]);
  }

  // Get the cells
  for (const auto &shape : objFile.shapes) {
    for (unsigned char num_face_vertice : shape.mesh.num_face_vertices) {
      if (num_face_vertice != 3) {
        throw std::runtime_error("Only triangular cells are supported");
      }
    }
    auto &indices = shape.mesh.indices;
    for (size_t i = 0; i < shape.mesh.num_face_vertices.size(); i++) {
      _connectivity[i] = Eigen::Vector3i(indices[3 * i].position_index, indices[3 * i + 1].position_index, indices[3 * i + 2].position_index);
    }
  }

  // Calculate the cell centers
  for (size_t i = 0; i < nCells; i++) {
    _cellCenters[i] = (_vertices[_connectivity[i](0)] + _vertices[_connectivity[i](1)] + _vertices[_connectivity[i](2)]) / 3;
  }

  // Calculate the cell tangents,normals and obliques
  for (size_t i = 0; i < nCells; i++) {
    Eigen::Vector3d v1 = _vertices[_connectivity[i](1)] - _vertices[_connectivity[i](2)];
    Eigen::Vector3d v2 = _vertices[_connectivity[i](1)] - _vertices[_connectivity[i](0)];
    _cellTangent[i]    = v1.normalized();
    _cellNormals[i]    = v1.cross(v2).normalized();
    _cellOblique[i]    = _cellNormals[i].cross(_cellTangent[i]);
  }

  calculateAICMatrix();
  calculateAICMatrixInv();
}

void Building::translateBuilding(const Eigen::Vector3d &translation)
{
  for (auto &_vertice : _vertices) {
    _vertice += translation;
  }
  for (auto &_cellCenter : _cellCenters) {
    _cellCenter += translation;
  }

  // Calculate the cell tangents,normals and obliques
  for (size_t i = 0; i < _cellCenters.size(); i++) {
    Eigen::Vector3d v1 = _vertices[_connectivity[i](1)] - _vertices[_connectivity[i](2)];
    Eigen::Vector3d v2 = _vertices[_connectivity[i](1)] - _vertices[_connectivity[i](0)];
    _cellTangent[i]    = v1.normalized();
    _cellNormals[i]    = v1.cross(v2).normalized();
    _cellOblique[i]    = _cellNormals[i].cross(_cellTangent[i]);
  }
}

void Building::rotateBuilding(const double q0, const double q1, const double q2, const double q3)
{
  Eigen::Quaterniond quad{q0, q1, q2, q3};
  for (auto &_vertice : _vertices) {
    _vertice = quad * _vertice;
  }
  for (auto &_cellCenter : _cellCenters) {
    _cellCenter = quad * _cellCenter;
  }
  // Calculate the cell tangents,normals and obliques
  for (size_t i = 0; i < _cellCenters.size(); i++) {
    Eigen::Vector3d v1 = _vertices[_connectivity[i](1)] - _vertices[_connectivity[i](2)];
    Eigen::Vector3d v2 = _vertices[_connectivity[i](1)] - _vertices[_connectivity[i](0)];
    _cellTangent[i]    = v1.normalized();
    _cellNormals[i]    = v1.cross(v2).normalized();
    _cellOblique[i]    = _cellNormals[i].cross(_cellTangent[i]);
  }
}

void Building::calculateAICMatrix()
{
  std::cout << "Calculating AIC matrix" << std::endl;
  const auto start{std::chrono::steady_clock::now()};

  size_t nCells = _connectivity.size();
#pragma omp parallel for collapse(2)
  for (size_t i = 0; i < nCells; i++) {
    for (size_t j = 0; j < nCells; j++) {
      const Eigen::Vector3d AIC = calculateVelocityDueToSinglePanel(_cellCenters[j], i);
      _AICMatrix(i, j)          = AIC.dot(_cellNormals[j]);
    }
  }
  const auto                          end{std::chrono::steady_clock::now()};
  const std::chrono::duration<double> elapsed_seconds{end - start};
  std::cout << elapsed_seconds.count() << "s\n";
}

void Building::calculateAICMatrixInv()
{
  std::cout << "Calculating AIC matrix inverse" << std::endl;
  const auto start{std::chrono::steady_clock::now()};
  _AICMatrixInv = _AICMatrix.inverse();
  const auto                          end{std::chrono::steady_clock::now()};
  const std::chrono::duration<double> elapsed_seconds{end - start};
  std::cout << elapsed_seconds.count() << "s\n";
}

void Building::calculateSigma(const std::vector<Eigen::Vector3d> &rhs)
{
  // Multiply RHS Velocity by normal vectors to construct actual RHS
  Eigen::VectorXd b(_cellCenters.size());
  for (size_t i = 0; i < _cellCenters.size(); i++) {
    b(i) = -(_cellNormals[i].dot(rhs[i])) + _safety_velocity;
  }
  _sigma = _AICMatrixInv * b;
}

Eigen::Vector3d Building::calculateVelocityAtPoint(const Eigen::Vector3d &point)
{
  Eigen::Vector3d velocity{0, 0, 0};
  for (size_t i = 0; i < _cellCenters.size(); i++) {
    velocity += calculateVelocityDueToSinglePanel(point, i) * _sigma(i);
  }
  return velocity;
}

std::vector<Eigen::Vector3d> &Building::getCellCenters()
{
  return _cellCenters;
}

void Building::setSafetyVelocity(const double sVelocity)
{
  _safety_velocity = sVelocity;
}
double Building::getSafetyVelocity() const
{
  return _safety_velocity;
}

void Building::dumpToVTK(const std::string &file)
{
  // Open the output file
  std::ofstream outfile(file);
  if (!outfile.is_open()) {
    std::cerr << "Error opening output file." << std::endl;
    return;
  }

  // Write the VTK header
  outfile << "# vtk DataFile Version 3.0\n";
  outfile << "Points example\n";
  outfile << "ASCII\n";
  outfile << "DATASET POLYDATA\n";

  // Write the points
  outfile << "POINTS " << _vertices.size() << " float\n";
  for (auto &vert : _vertices) {
    outfile << vert.transpose() << "\n";
  }
  // Close the file
  outfile.close();

  std::cout << "VTK file written successfully." << std::endl;
}