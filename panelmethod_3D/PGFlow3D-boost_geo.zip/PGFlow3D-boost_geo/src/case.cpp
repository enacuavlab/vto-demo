//  ███████████    █████████  ███████████ ████                               ████████  ██████████
// ░░███░░░░░███  ███░░░░░███░░███░░░░░░█░░███                              ███░░░░███░░███░░░░███
//  ░███    ░███ ███     ░░░  ░███   █ ░  ░███   ██████  █████ ███ █████   ░░░    ░███ ░███   ░░███
//  ░██████████ ░███          ░███████    ░███  ███░░███░░███ ░███░░███       ██████░  ░███    ░███
//  ░███░░░░░░  ░███    █████ ░███░░░█    ░███ ░███ ░███ ░███ ░███ ░███      ░░░░░░███ ░███    ░███
//  ░███        ░░███  ░░███  ░███  ░     ░███ ░███ ░███ ░░███████████      ███   ░███ ░███    ███
//  █████        ░░█████████  █████       █████░░██████   ░░████░████      ░░████████  ██████████
// ░░░░░          ░░░░░░░░░  ░░░░░       ░░░░░  ░░░░░░     ░░░░ ░░░░        ░░░░░░░░  ░░░░░░░░░░

// =========================================================================
//  Copyright (C) 2024-2024 Technical University of Munich, ENAC - Ecole Nationale de l'Aviation Civile
//  This file is part of PGFlow3D.

//  Permission is hereby granted, free of charge, to any person
//  obtaining a copy of this software and associated documentation
//  files (the "Software"), to deal in the Software without
//  restriction, including without limitation the rights to use,
//  copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following
//  conditions:

//  The above copyright notice and this permission notice shall be
//  included in all copies or substantial portions of the Software.

//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//  OTHER DEALINGS IN THE SOFTWARE.

//  Authors:
//           M Kuersat Yurt, MSc. (TUM)
// =========================================================================

#include "case.hpp"
#include <cassert>

void Case::addVehicle()
{
  _vehicles.emplace_back();
}

void Case::addGoal()
{
  _goals.emplace_back();
}

void Case::addBuilding()
{
  _buildings.emplace_back();
}

Goal &Case::getGoal(size_t index)
{
  return _goals[index];
}

Building &Case::getBuilding(size_t index)
{
  return _buildings[index];
}

void Case::setVehiclePosition(size_t index, const Eigen::Vector3d &position)
{
  assert(index < _vehicles.size());
  _vehicles[index].setPosition(position);
}

void Case::setVehicleVelocity(size_t index, const Eigen::Vector3d &velocity)
{
  assert(index < _vehicles.size());
  _vehicles[index].setVelocity(velocity);
}

void Case::setVehicleSourceStrength(size_t index, double sourceStrength)
{
  assert(index < _vehicles.size());
  _vehicles[index].setStrength(sourceStrength);
}

void Case::setVehiclePriority(size_t index, const double priority)
{
  assert(index < _vehicles.size());
  _vehicles[index].setPriority(priority);
}

Eigen::Vector3d Case::getVehiclePosition(size_t index)
{
  assert(index < _vehicles.size());
  return _vehicles[index].getPosition();
}

Eigen::Vector3d Case::getVehicleVelocity(size_t index)
{
  assert(index < _vehicles.size());
  return _vehicles[index].getVelocity();
}

void Case::setGoalPosition(size_t index, const Eigen::Vector3d &position)
{
  assert(index < _goals.size());
  _goals[index].setPosition(position);
}

void Case::setGoalStrength(size_t index, double strength)
{
  assert(index < _goals.size());
  _goals[index].setStrength(strength);
}

void Case::initBuildingFromOBJFile(size_t index, const std::string &filename)
{
  assert(index < _buildings.size());
  _buildings[index].initFromOBJFile(filename);
}

void Case::translateBuilding(size_t index, const Eigen::Vector3d &translation)
{
  assert(index < _buildings.size());
  _buildings[index].translateBuilding(translation);
}

void Case::rotateBuilding(size_t index, const double q0, const double q1, const double q2, const double q3)
{
  assert(index < _buildings.size());
  _buildings[index].rotateBuilding(q0, q1, q2, q3);
}

void Case::dumpBuildingToVTK(size_t index, const std::string &file)
{
  assert(index < _buildings.size());
  _buildings[index].dumpToVTK(file);
}

void Case::setFreeStream(const Eigen::Vector3d &freestream)
{
  _freestream = freestream;
}

Eigen::Vector3d Case::getFreeStream() const
{
  return _freestream;
}

size_t Case::getNumberOfVehicles() const
{
  return _vehicles.size();
}

size_t Case::getNumberOfBuildings() const
{
  return _buildings.size();
}

void Case::calculateVehicleVelocities(const double safety_source_strength)
{
  // Calculate the velocity at each vehicle's position
  const size_t nBuildings = _buildings.size();
  const size_t nVehicles  = _vehicles.size();
#pragma omp parallel for
  for (size_t i = 0; i < nVehicles; ++i) {
    // Set the velocity to the freestream velocity
    Eigen::Vector3d velocity = _freestream;
    // Interaction with it's goal
    {
      // Calculate distance with it is goal
      auto distance = (_goals[i].getPosition() - _vehicles[i].getPosition()).norm();
      // Set the goal strength to distance cubed
      _goals[i].setStrength(-(distance * distance * distance));
      // Add the velocity due to the goal to the vehicle's velocity
      velocity += _goals[i].calculateVelocityAtPoint(_vehicles[i].getPosition());
    }
    // Set the strength of the other vehicles to 1/distance^3
    for (size_t j = 0; j < nVehicles; ++j) {
      if (j != i) {
        // Calculate the distance between the vehicles
        auto distance = (_vehicles[j].getPosition() - _vehicles[i].getPosition()).norm();
        // Set the strength to 1/distance^3
        _vehicles[j].setStrength(1.0 / (distance * distance * distance));
      } else {
        _vehicles[j].setStrength(safety_source_strength);
      }
    }
    // Now for each building calculate the velocity due to the building
#pragma omp parallel for
    for (size_t j = 0; j < nBuildings; ++j) {
      auto cellCenters = _buildings[j].getCellCenters();

      std::vector<Eigen::Vector3d> rhs(cellCenters.size());

      for (size_t k = 0; k < cellCenters.size(); ++k) {
        rhs[k] = _goals[i].calculateVelocityAtPoint(cellCenters[k]);
        // Contribution of the other vehicles to building RHS
        for (size_t l = 0; l < nVehicles; ++l) {
          // if (l != i) {
          rhs[k] += _vehicles[l].calculateVelocityAtPoint(cellCenters[k]);
          // }
        }
        rhs[k] += _freestream;
      }
      _buildings[j].calculateSigma(rhs);
      velocity += _buildings[j].calculateVelocityAtPoint(_vehicles[i].getPosition());
    }
    // Now interact with other vehicles
    for (size_t j = 0; j < nVehicles; ++j) {
      if (j != i) {
        velocity += _vehicles[j].calculateVelocityAtPoint(_vehicles[i].getPosition());
      }
    }
    // Set the vehicle's velocity to the calculated velocity
    _vehicles[i].setVelocity(velocity);
  }
}

void Case::advanceVehicles(const double dt)
{
  // Simple Euler integration
  for (auto &vehicle : _vehicles) {
    vehicle.setPosition(vehicle.getPosition() + vehicle.getVelocity() / vehicle.getVelocity().norm() * dt);
  }
}

Vehicle &Case::getVehicle(size_t index)
{
  return _vehicles[index];
}

double Case::getBuildingSafetyVelocity(size_t index)
{
  return _buildings[index].getSafetyVelocity();
}

void Case::setBuildingSafetyVelocity(size_t index, double safetyVelocity)
{
  _buildings[index].setSafetyVelocity(safetyVelocity);
}

void Case::setGoalReachDistance(double goalReachDistance)
{
  _goalReachDistance = goalReachDistance;
}
double Case::getGoalReachDistance() const
{
  return _goalReachDistance;
}

bool Case::isGoalReached(size_t index)
{
  return (_goals[index].getPosition() - _vehicles[index].getPosition()).norm() < _goalReachDistance;
}

void Case::calculateVehicleVelocitiesWithGuidanceStream(const double GSFactor, const double safety_source_strength)
{
  // Calculate the velocity at each vehicle's position
  const size_t nBuildings = _buildings.size();
  const size_t nVehicles  = _vehicles.size();
#pragma omp parallel for
  for (size_t i = 0; i < nVehicles; ++i) {
    // Set the velocity to zero
    Eigen::Vector3d velocity = Eigen::Vector3d::Zero();
    // Add a freestreamlike velocity towards the goal
    const Eigen::Vector3d guidanceStream = GSFactor * (_goals[i].getPosition() - _vehicles[i].getPosition()).normalized();
    velocity += guidanceStream;
    // Interaction with it's goal
    {
      // Calculate distance with it is goal
      auto distance = (_goals[i].getPosition() - _vehicles[i].getPosition()).norm();
      // Set the goal strength to distance cubed
      _goals[i].setStrength(-(distance * distance * distance));
      // Add the velocity due to the goal to the vehicle's velocity
      velocity += _goals[i].calculateVelocityAtPoint(_vehicles[i].getPosition());
    }
    // Set the strength of the other vehicles to 1/distance^3
    for (size_t j = 0; j < nVehicles; ++j) {
      if (j != i) {
        // Calculate the distance between the vehicles
        auto distance = (_vehicles[j].getPosition() - _vehicles[i].getPosition()).norm();
        // Set the strength to 1/distance^3
        _vehicles[j].setStrength(1.0 / (distance * distance * distance));
      }
    }
    _vehicles[i].setStrength(safety_source_strength);
// Now for each building calculate the velocity due to the building
#pragma omp parallel for
    for (size_t j = 0; j < nBuildings; ++j) {
      auto cellCenters = _buildings[j].getCellCenters();

      std::vector<Eigen::Vector3d> rhs(cellCenters.size());

      for (size_t k = 0; k < cellCenters.size(); ++k) {
        rhs[k] = _goals[i].calculateVelocityAtPoint(cellCenters[k]);
        rhs[k] += guidanceStream;
        // Contribution of the other vehicles to building RHS
        for (size_t l = 0; l < nVehicles; ++l) {
          // if (l != i) {
          rhs[k] += _vehicles[l].calculateVelocityAtPoint(cellCenters[k]);
          // }
        }
      }
      _buildings[j].calculateSigma(rhs);
      velocity += _buildings[j].calculateVelocityAtPoint(_vehicles[i].getPosition());
    }
    // Now interact with other vehicles
    for (size_t j = 0; j < nVehicles; ++j) {
      if (j != i) {
        velocity += _vehicles[j].calculateVelocityAtPoint(_vehicles[i].getPosition());
      }
    }
    // This is for escaping from the stagnation point
    double velocity_norm = velocity.norm();
    if (velocity_norm < 0.001) {
      velocity_norm = 0.01;
    }
    const Eigen::Vector3d guidanceStream2 = velocity_norm * GSFactor * (_goals[i].getPosition() - _vehicles[i].getPosition()).normalized();
    velocity += guidanceStream2;
    // Set the vehicle's velocity to the calculated velocity
    // If the goal is reached, set the velocity to zero and continue
    if (isGoalReached(i)) {
      _vehicles[i].setVelocity(Eigen::Vector3d::Zero());
      continue;
    }
    _vehicles[i].setVelocity(velocity);
  }
}

Eigen::Vector3d Case::getGoalPosition(size_t index)
{
  return _goals[index].getPosition();
}

void Case::createVehicleRtree()
{
  const auto numberOfVehicles = _vehicles.size();
  _vehicleRtree.clear();

  for (size_t i = 0; i < numberOfVehicles; ++i) {
    _vehicleRtree.insert(std::make_pair(_vehicles[i].getPosition(), i));
  }
}

void Case::createBuildingRtree()
{
  const auto numberOfBuildings = _buildings.size();
  _buildingRtree.clear();

  for (size_t i = 0; i < numberOfBuildings; ++i) {
    Poly       polygon;
    Box        box;
    const auto cellCenters = _buildings[i].getCellCenters();
    for (size_t j = 0; j < cellCenters.size(); ++j) {
      polygon.outer().push_back(cellCenters[j]);
    }
    boost::geometry::envelope(polygon, box);
    _buildingBoxes.push_back(box);
    _buildingRtree.insert(std::make_pair(box, i));
  }
}

std::vector<size_t> Case::findNearbyVehicles(const size_t index, const double radius)
{
  if (!_thisRoundHasVehicleRtree) {
    createVehicleRtree();
    _thisRoundHasVehicleRtree = true;
  }

  std::vector<std::pair<Eigen::Vector3d, unsigned>> result;
  _vehicleRtree.query(boost::geometry::index::satisfies([&](const std::pair<Eigen::Vector3d, size_t> &value) {
                        return (value.first - _vehicles[index].getPosition()).norm() < radius;
                      }),
                      std::back_inserter(result));

  std::vector<size_t> vehicleIndices;
  vehicleIndices.reserve(result.size());
  for (const auto &[position, vehicleIndex] : result) {
    vehicleIndices.push_back(vehicleIndex);
  }
  return vehicleIndices;
}

std::vector<size_t> Case::findNearbyBuildings(const size_t index, const double radius)
{
  if (_buildingRtree.empty()) {
    createBuildingRtree();
  }

  const auto            queryPoint = _vehicles[index].getPosition();
  const Eigen::Vector3d minCorner  = queryPoint - Eigen::Vector3d(radius, radius, radius);
  const Eigen::Vector3d maxCorner  = queryPoint + Eigen::Vector3d(radius, radius, radius);

  const Box searchBox(minCorner, maxCorner);

  std::vector<std::pair<Box, unsigned>> result;
  _buildingRtree.query(bgi::intersects(searchBox), std::back_inserter(result));

  std::vector<size_t> buildingIndices;
  buildingIndices.reserve(result.size());
  for (const auto &[box, buildingIndex] : result) {
    buildingIndices.push_back(buildingIndex);
  }
  return buildingIndices;
}

double Case::getNearestBuildingDistance(const size_t index)
{
  return _nearestBuildingDistance[index];
}

double Case::getGoalDistance(const size_t index)
{
  return bg::distance(_vehicles[index].getPosition(), _goals[index].getPosition());
}

void Case::calculateVehicleVelocitiesWithGuidanceStreamAdaptively(const double GSFactor, const double vehicleRadius, const double buildingRadius, const double safety_source_strength)
{
  _vehicleRtree.clear();
  createVehicleRtree();
  if (_buildingRtree.empty()) {
    createBuildingRtree();
  }
  _thisRoundHasVehicleRtree = true;

  // Calculate the velocity at each vehicle's position
  const size_t nVehicles = _vehicles.size();
  _nearestBuildingDistance.clear();
  _nearestBuildingDistance.resize(nVehicles);
  for (size_t i = 0; i < nVehicles; ++i) {
    // Find the nearest buildings distance from the vehicle
    std::vector<std::pair<Box, unsigned>> result;
    const Eigen::Vector3d                 vec_position = _vehicles[i].getPosition();
    _buildingRtree.query(bgi::nearest(_vehicles[i].getPosition(), 1), std::back_inserter(result));
    _nearestBuildingDistance[i] = bg::distance(vec_position, _buildingBoxes[result[0].second]);
    // Set the velocity to zero
    Eigen::Vector3d velocity = Eigen::Vector3d::Zero();
    // Add a freestreamlike velocity towards the goal
    const Eigen::Vector3d guidanceStream = GSFactor * (_goals[i].getPosition() - _vehicles[i].getPosition()).normalized();
    velocity += guidanceStream;
    // Interaction with it's goal
    {
      // Calculate distance with it is goal
      auto distance = (_goals[i].getPosition() - _vehicles[i].getPosition()).norm();
      // Set the goal strength to distance cubed
      _goals[i].setStrength(-(distance * distance * distance));
      // Add the velocity due to the goal to the vehicle's velocity
      velocity += _goals[i].calculateVelocityAtPoint(_vehicles[i].getPosition());
    }
    // Get Vehicles within the radius
    auto nearbyVehicles = findNearbyVehicles(i, vehicleRadius);
    // Set the strength of the other vehicles to 1/distance^3
    for (const auto j : nearbyVehicles) {
      if (j != i) {
        // Calculate the distance between the vehicles
        auto distance = (_vehicles[j].getPosition() - _vehicles[i].getPosition()).norm();
        // Set the strength to 1/distance^3
        _vehicles[j].setStrength(1.0 / (distance * distance * distance));
      }
    }
    _vehicles[i].setStrength(safety_source_strength);
    // Get Buildings within the radius
    auto nearbyBuildings = findNearbyBuildings(i, buildingRadius);
    // Now for each building calculate the velocity due to the building
#pragma omp parallel for
    for (const auto j : nearbyBuildings) {
      auto cellCenters = _buildings[j].getCellCenters();

      std::vector<Eigen::Vector3d> rhs(cellCenters.size());

      for (size_t k = 0; k < cellCenters.size(); ++k) {
        rhs[k] = _goals[i].calculateVelocityAtPoint(cellCenters[k]);
        rhs[k] += guidanceStream;
        // Contribution of the other vehicles to building RHS
        for (size_t l = 0; l < nVehicles; ++l) {
          // if (l != i) {
          rhs[k] += _vehicles[l].calculateVelocityAtPoint(cellCenters[k]);
          // }
        }
      }
      _buildings[j].calculateSigma(rhs);
      velocity += _buildings[j].calculateVelocityAtPoint(_vehicles[i].getPosition());
    }
    // Now interact with other vehicles
    for (const auto j : nearbyVehicles) {
      if (j != i) {
        velocity += _vehicles[j].calculateVelocityAtPoint(_vehicles[i].getPosition());
      }
    }
    // This is for escaping from the stagnation point
    double velocity_norm = velocity.norm();
    if (velocity_norm < 0.001) {
      velocity_norm = 0.01;
    }
    const Eigen::Vector3d guidanceStream2 = velocity_norm * GSFactor * (_goals[i].getPosition() - _vehicles[i].getPosition()).normalized();
    velocity += guidanceStream2;
    // Set the vehicle's velocity to the calculated velocity
    _vehicles[i].setVelocity(velocity);
    // If the goal is reached, set the velocity to zero and continue
    if (isGoalReached(i)) {
      _vehicles[i].setVelocity(Eigen::Vector3d::Zero());
    }
  }
  _thisRoundHasVehicleRtree = false;
}