//  ███████████    █████████  ███████████ ████                               ████████  ██████████
// ░░███░░░░░███  ███░░░░░███░░███░░░░░░█░░███                              ███░░░░███░░███░░░░███
//  ░███    ░███ ███     ░░░  ░███   █ ░  ░███   ██████  █████ ███ █████   ░░░    ░███ ░███   ░░███
//  ░██████████ ░███          ░███████    ░███  ███░░███░░███ ░███░░███       ██████░  ░███    ░███
//  ░███░░░░░░  ░███    █████ ░███░░░█    ░███ ░███ ░███ ░███ ░███ ░███      ░░░░░░███ ░███    ░███
//  ░███        ░░███  ░░███  ░███  ░     ░███ ░███ ░███ ░░███████████      ███   ░███ ░███    ███
//  █████        ░░█████████  █████       █████░░██████   ░░████░████      ░░████████  ██████████
// ░░░░░          ░░░░░░░░░  ░░░░░       ░░░░░  ░░░░░░     ░░░░ ░░░░        ░░░░░░░░  ░░░░░░░░░░

// =========================================================================
//  Copyright (C) 2024-2024 Technical University of Munich, ENAC - Ecole Nationale de l'Aviation Civile
//  This file is part of PGFlow3D.

//  Permission is hereby granted, free of charge, to any person
//  obtaining a copy of this software and associated documentation
//  files (the "Software"), to deal in the Software without
//  restriction, including without limitation the rights to use,
//  copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following
//  conditions:

//  The above copyright notice and this permission notice shall be
//  included in all copies or substantial portions of the Software.

//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//  OTHER DEALINGS IN THE SOFTWARE.

//  Authors:
//           M Kuersat Yurt, MSc. (TUM)
// =========================================================================

#include <pybind11/eigen.h>
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "case.hpp"
namespace py = pybind11;

PYBIND11_MODULE(PGFlow3D, m)
{
  py::class_<Case>(m, "Case")
      .def(py::init<>())
      .def("addVehicle", &Case::addVehicle)
      .def("addGoal", &Case::addGoal)
      .def("addBuilding", &Case::addBuilding)
      .def("setVehiclePosition", &Case::setVehiclePosition)
      .def("setVehicleVelocity", &Case::setVehicleVelocity)
      .def("setVehicleSourceStrength", &Case::setVehicleSourceStrength)
      .def("setVehiclePriority", &Case::setVehiclePriority)
      .def("getVehiclePosition", &Case::getVehiclePosition)
      .def("getVehicleVelocity", &Case::getVehicleVelocity)
      .def("setGoalPosition", &Case::setGoalPosition)
      .def("setGoalStrength", &Case::setGoalStrength)
      .def("getGoalPosition", &Case::getGoalPosition)
      .def("setFreeStream", &Case::setFreeStream)
      .def("getFreeStream", &Case::getFreeStream)
      .def("getNumberOfVehicles", &Case::getNumberOfVehicles)
      .def("getNumberOfBuildings", &Case::getNumberOfBuildings)
      .def("calculateVehicleVelocities", &Case::calculateVehicleVelocities, py::arg("safety_source_strength") = 1.0)
      .def("calculateVehicleVelocitiesWithGuidanceStream", &Case::calculateVehicleVelocitiesWithGuidanceStream, py::arg("GSFactor") = 1.0, py::arg("safety_source_strength") = 1.0)
      .def("calculateVehicleVelocitiesWithGuidanceStreamAdaptively", &Case::calculateVehicleVelocitiesWithGuidanceStreamAdaptively, py::arg("GSFactor") = 1.0, py::arg("vehicleRadius") = 5.0, py::arg("buildingRadius") = 5.0, py::arg("safety_source_strength") = 1.0)
      .def("getNearestBuildingDistance", &Case::getNearestBuildingDistance)
      .def("getGoalDistance",&Case::getGoalDistance)
      .def("advanceVehicles", &Case::advanceVehicles)
      .def("setGoalReachDistance", &Case::setGoalReachDistance)
      .def("getGoalReachDistance", &Case::getGoalReachDistance)
      .def("isGoalReached", &Case::isGoalReached)
      .def("initBuildingFromOBJFile", &Case::initBuildingFromOBJFile)
      .def("getBuildingSafetyVelocity", &Case::getBuildingSafetyVelocity)
      .def("setBuildingSafetyVelocity", &Case::setBuildingSafetyVelocity)
      .def("translateBuilding", &Case::translateBuilding)
      .def("dumpBuildingToVTK", &Case::dumpBuildingToVTK)
      .def("rotateBuilding", &Case::rotateBuilding);
}
