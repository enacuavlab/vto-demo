#!/usr/bin/env python3

import numpy as np
from tqdm import tqdm
import meshio

import PGFlow3D

# Create PGFlow3D case
myCase = PGFlow3D.Case()

# Add building
myCase.addBuilding()
myCase.initBuildingFromOBJFile(
    0, "obstacle.obj"
)  # This can be created using the mesh examples

# Add a vehicle and goal for the vehicle
myCase.addVehicle()
myCase.setVehiclePosition(0, np.array([2.5, 2.5, 2.5]))
myCase.addGoal()
myCase.setGoalPosition(0, np.array([-2.5, -2.5, 2.5]))

# Store the vehicle locations
locs = []
locs.append(myCase.getVehiclePosition(0))

# Run the simulation
for i in tqdm(range(1000)):
    myCase.calculateVehicleVelocities()
    myCase.advanceVehicles(0.1)
    locs.append(myCase.getVehiclePosition(0))

# Write the vehicle locations to a VTK file
cells = [
    (
        "vertex",
        np.array([[i] for i in range(len(locs))]),
    )
]
mesh = meshio.Mesh(locs, cells)
mesh.write("vehicle.vtk")
