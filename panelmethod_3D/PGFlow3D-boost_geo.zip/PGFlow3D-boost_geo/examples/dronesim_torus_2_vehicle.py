#!/usr/bin/env python3

"""Script demonstrating the joint use of PGFlow3D and DroneSim.

The simulation is run by a `DroneSim VelocityAviary` environment.

Example
-------
In a terminal, run as:

    $ python3 dronesim_example.py
    
"""
import os
import time
import argparse
from datetime import datetime
import pdb
import math
import random
import numpy as np
import pybullet as p

from time import sleep
import numpy as np

import meshio

from dronesim.envs.BaseAviary import DroneModel, Physics
from dronesim.envs.VelocityAviary import VelocityAviary
from dronesim.utils.utils import sync, str2bool

from PGFlow3D import *


def main():
    #### Define and parse (optional) arguments for the script ##
    parser = argparse.ArgumentParser(
        description="Velocity control example using VelocityAviary"
    )
    parser.add_argument(
        "--drone",
        default=["tello"],
        type=str,
        help="Drone model (default: CF2X)",
        metavar="",
        choices=DroneModel,
    )
    parser.add_argument(
        "--gui",
        default=True,
        type=str2bool,
        help="Whether to use PyBullet GUI (default: True)",
        metavar="",
    )
    parser.add_argument(
        "--record_video",
        default=False,
        type=str2bool,
        help="Whether to record a video (default: False)",
        metavar="",
    )
    parser.add_argument(
        "--plot",
        default=True,
        type=str2bool,
        help="Whether to plot the simulation results (default: True)",
        metavar="",
    )
    parser.add_argument(
        "--user_debug_gui",
        default=False,
        type=str2bool,
        help="Whether to add debug lines and parameters to the GUI (default: False)",
        metavar="",
    )
    parser.add_argument(
        "--aggregate",
        default=True,
        type=str2bool,
        help="Whether to aggregate physics steps (default: False)",
        metavar="",
    )
    parser.add_argument(
        "--obstacles",
        default=True,
        type=str2bool,
        help="Whether to add obstacles to the environment (default: True)",
        metavar="",
    )
    parser.add_argument(
        "--simulation_freq_hz",
        default=240,
        type=int,
        help="Simulation frequency in Hz (default: 240)",
        metavar="",
    )
    parser.add_argument(
        "--control_freq_hz",
        default=24,
        type=int,
        help="Control frequency in Hz (default: 48)",
        metavar="",
    )
    parser.add_argument(
        "--flow_calc_freq_hz",
        default=24,
        type=int,
        help="Vector field calculation frequency in Hz (default: 5)",
        metavar="",
    )
    parser.add_argument(
        "--duration_sec",
        default=90,
        type=int,
        help="Duration of the simulation in seconds (default: 5)",
        metavar="",
    )
    # parser.add_argument('--duration_sec',       default=90,         type=int,           help='Duration of the simulation in seconds (default: 5)', metavar='')
    ARGS = parser.parse_args()

    AGGR_PHY_STEPS = (
        int(ARGS.simulation_freq_hz / ARGS.control_freq_hz) if ARGS.aggregate else 1
    )
    PHY = Physics.PYB

    #### Initialize the simulation #############################

    case = Case()

    # Add building
    case.addBuilding()
    case.initBuildingFromOBJFile(0, "obstacle.obj")
    case.setBuildingSafetyVelocity(0, 0.05)

    case.addVehicle()
    case.setVehiclePosition(0, np.array([0, -3.5, 2.0]))
    case.addGoal()
    case.setGoalPosition(0, np.array([0, 3.5, 2.0]))

    case.addVehicle()
    case.setVehiclePosition(1, np.array([0, 3.5, 2.0]))
    case.addGoal()
    case.setGoalPosition(1 , np.array([0, -3.5, 2.0]))

    num_vehicles = case.getNumberOfVehicles()

    INIT_XYZS = np.array([case.getVehiclePosition(i) for i in range(num_vehicles)])
    INIT_RPYS = np.zeros([num_vehicles, 3])

    #### Create the environment ################################
    env = VelocityAviary(
        drone_model=num_vehicles * ARGS.drone,
        num_drones=num_vehicles,
        initial_xyzs=INIT_XYZS,
        initial_rpys=INIT_RPYS,
        physics=Physics.PYB,
        neighbourhood_radius=10,
        freq=ARGS.simulation_freq_hz,
        aggregate_phy_steps=AGGR_PHY_STEPS,
        gui=ARGS.gui,
        record=ARGS.record_video,
        obstacles=ARGS.obstacles,
        user_debug_gui=ARGS.user_debug_gui,
    )
    #### Obtain the PyBullet Client ID from the environment ####
    PYB_CLIENT = env.getPyBulletClient()
    DRONE_IDS = env.getDroneIds()

    ### Add ground plane
    PLANE_ID = p.loadURDF("plane.urdf", physicsClientId=PYB_CLIENT)
    PLANE_ID = p.loadURDF("obstacle.urdf", physicsClientId=PYB_CLIENT)

    #### Run the simulation ####################################
    action = {str(i): np.array([0.0, 0.0, 0.0, 0.0]) for i in range(num_vehicles)}
    START = time.time()
    
    
    # Store the vehicle locations
    locs = [[] for _ in range(num_vehicles)]
    for i in range(num_vehicles):
        locs[i].append(case.getVehiclePosition(i))



    for i in range(0, int(ARGS.duration_sec * env.SIM_FREQ), AGGR_PHY_STEPS):
        #### Step the simulation ###################################
        obs, reward, done, info = env.step(action)

        # write the current position and velocity observation into vehicles
        for vehicle_nr in range(num_vehicles):
            case.setVehiclePosition(vehicle_nr, obs[str(vehicle_nr)]["state"][0:3])
            locs[vehicle_nr].append(case.getVehiclePosition(vehicle_nr))

        case.calculateVehicleVelocities()
        for vehicle_nr in range(num_vehicles):
            V_des = case.getVehicleVelocity(vehicle_nr)
            pos = case.getVehiclePosition(vehicle_nr)
            if pos[2] < 0.2:
                V_des[2] = 0.0
            mag = np.linalg.norm(V_des)
            V_des_unit = V_des / mag
            mag = np.clip(mag, 0.0, 0.4)
            mag_converted = mag / 8.3  # This is Tellos max speed 30Km/h
            action[str(vehicle_nr)] = np.array(
                [V_des_unit[0], V_des_unit[1], V_des_unit[2], mag_converted]
            )  # This is not incremental ! It is direct desired action.

        #### Printout ##############################################
        if i % env.SIM_FREQ == 0:
            env.render()

        #### Sync the simulation ###################################
        if ARGS.gui:
            sync(i, START, env.TIMESTEP)
    #### Close the environment #################################
    env.close()


    # Write the vehicle locations to a VTK file
    cells = [
        (
            "vertex",
            np.array([[i] for i in range(len(locs[0]))]),
        )
    ]

    for i in range(num_vehicles):
        mesh = meshio.Mesh(locs[i], cells)
        mesh.write(f"vehicle_dronesim_{i}.vtk")



if __name__ == "__main__":
    main()
