#!/usr/bin/env python3

import numpy as np
import meshio
from copy import deepcopy

base_mesh = meshio.read("obstacle.obj")

print(base_mesh.cells_dict["triangle"].shape)

# base_mesh.points += np.array([0.5,1.0,0])

# base_mesh.write('obstacle.obj')

translation_radius= 8.0
azimuthal_buildings = 10

for azimuth in np.linspace(0, 360, azimuthal_buildings):
    rotated_mesh = deepcopy(base_mesh)
    rotated_mesh.points[:, 0] += translation_radius * np.cos(np.radians(azimuth))
    rotated_mesh.points[:, 1] += translation_radius * np.sin(np.radians(azimuth))
    rotated_mesh.write(f"obstacle_{translation_radius:.0f}_{azimuth:.0f}.obj") 



