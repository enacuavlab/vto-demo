#!/usr/bin/env python3

import glob


obj_files = glob.glob("obstacle*.obj")

for obj_file in obj_files:
    file_without_extension = obj_file.split(".")[0]
    with open(f"{file_without_extension}.urdf", "+tw") as f:
        f.write(
            f"""
                <?xml version="1.0" ?>

<robot name="obstacle">

  <link concave="yes" name="base_link"> 

    <inertial>
      <origin rpy="0 0 0" xyz="0 0 0"/>
      <mass value="0.0"/>
      <inertia ixx="100" ixy="100.0" ixz="100.0" iyy="100" iyz="100.0" izz="100"/>
    </inertial>

    <visual>
      <origin rpy="0 0 0" xyz="0 0 0"/>
      <geometry>
        <!-- <box size=".5 .5 1.5" /> -->
        <mesh filename="./{obj_file}" scale="1.0 1.0 1.0"/>
      </geometry> 
      <material name="red">
        <color rgba="1. 0. 0. 1.0"/>
      </material> 
    </visual>

    <collision concave="yes">
      <origin rpy="0 0 0" xyz="0 0 0"/>
      <geometry>
        <mesh filename="./{obj_file}" scale="1.0 1.0 1.0"/>
      </geometry>
    </collision>  

  </link>

</robot>

"""
        )
