#!/usr/bin/env python3

#!/usr/bin/env python3

import numpy as np
import meshio
from copy import deepcopy

base_mesh = meshio.read("obstacle.obj")
base_mesh.points += np.array([0.5, 1.0, 0])

orj_points = deepcopy(base_mesh.points)
orj_cell_dict = deepcopy(base_mesh.cells_dict["triangle"])

# base_mesh.write('obstacle.obj')
points_list = [orj_points]
cells_list = [orj_cell_dict]

translation_radius = 5
azimuthal_buildings = 10

for i, azimuth in enumerate(np.linspace(0, 360, azimuthal_buildings)):
    rotated_mesh = deepcopy(base_mesh)
    rotated_mesh.points[:, 0] += translation_radius * np.cos(np.radians(azimuth))
    rotated_mesh.points[:, 1] += translation_radius * np.sin(np.radians(azimuth))
    points_list.append(rotated_mesh.points)
    cells_list.append(
        rotated_mesh.cells_dict["triangle"] + orj_points.shape[0] * (i + 1)
    )

meshio.Mesh(
    points=np.vstack(points_list), cells={"triangle": np.vstack(cells_list)}
).write("obstacle_merged.obj")
