#!/usr/bin/env python3

import numpy as np
from tqdm import tqdm
import meshio

import PGFlow3D
import glob

# Create PGFlow3D case
case = PGFlow3D.Case()

building_files = glob.glob("obstacle*.obj")

for i, building_file in enumerate(building_files):
    case.addBuilding()
    case.initBuildingFromOBJFile(i, building_file)
    case.setBuildingSafetyVelocity(i, 0.2)
    
nv = 5
for i, azimuth in enumerate(np.linspace(0, 180, nv,endpoint=True)):
    case.addVehicle()
    case.setVehiclePosition(
        i,
        np.array(
            [3 * np.cos(np.radians(azimuth)), 3 * np.sin(np.radians(azimuth)), 1.0]
        ),
    )
    case.addGoal()
    case.setGoalPosition(
        i,
        np.array(
            [3 * np.cos(np.radians(azimuth+180)), 3 * np.sin(np.radians(azimuth+180)), 1.0]
        ),
    )

n_vehicles = case.getNumberOfVehicles()
# Store the vehicle locations
locs = [[] for _ in range(n_vehicles)]
for i in range(n_vehicles):
    locs[i].append(case.getVehiclePosition(i))

# Run the simulation
for i in tqdm(range(2000)):
    case.calculateVehicleVelocities()
    for j in range(n_vehicles):
        vel = case.getVehicleVelocity(j)
        pos = case.getVehiclePosition(j)
        if pos[2] < 0.2 or pos[2] > 2.2:
            case.setVehicleVelocity(j, np.array([vel[0], vel[1], 0.0]))
    case.advanceVehicles(0.05)
    for i in range(n_vehicles):
        locs[i].append(case.getVehiclePosition(i))

# Write the vehicle locations to a VTK file
cells = [
    (
        "vertex",
        np.array([[i] for i in range(len(locs[0]))]),
    )
]

for i in range(n_vehicles):
    mesh = meshio.Mesh(locs[i], cells)
    mesh.write(f"vehicle_{i}.vtk")
