#!/usr/bin/env python3

import pygalmesh

domain = pygalmesh.Tetrahedron(
    [0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]
)
mesh = pygalmesh.generate_surface_mesh(
    domain,
    min_facet_angle=1.0,
    max_radius_surface_delaunay_ball=0.02,
    max_facet_distance=0.2,
    verbose=True,
)

mesh.write("obstacle.obj")