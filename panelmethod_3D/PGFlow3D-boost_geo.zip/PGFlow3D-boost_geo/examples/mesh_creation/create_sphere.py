#!/usr/bin/env python3


import pygalmesh

# Create a sphere
center = [0.0, 0.0, 2.0]
radius = 2.0
s = pygalmesh.Ball(center, radius)
mesh = pygalmesh.generate_surface_mesh(
    s,
    min_facet_angle=1.0,
    max_radius_surface_delaunay_ball=0.1,
    max_facet_distance=0.01,
)

mesh.write("obstacle.obj")
