import pygalmesh
import numpy as np

# Create a 2D Polygonal Base
p = pygalmesh.Polygon2D(
    [
        [0.0, 0.0],
        [1.0, 0.0],
        [1.5, np.sqrt(3) / 2],
        [1.0, np.sqrt(3)],
        [0.0, np.sqrt(3)],
        [-0.5, np.sqrt(3) / 2],
    ]
)
# Define the height of the Extrusion
height = 2.0
max_edge_size_at_feature_edges = 0.1
rotation = 0  # in radians
# Create the Domain by Extruding the Polygonal Base
domain = pygalmesh.Extrude(
    p,
    [0.0, 0.0, height],
    rotation,
    max_edge_size_at_feature_edges,
)
# # Generate the Mesh
mesh = pygalmesh.generate_surface_mesh(
    domain,
    min_facet_angle=1.0,
    max_radius_surface_delaunay_ball=0.15,
    max_facet_distance=0.05,
    verbose=True,
)
# Write the Mesh to a VTK File
mesh.write("obstacle.obj")
