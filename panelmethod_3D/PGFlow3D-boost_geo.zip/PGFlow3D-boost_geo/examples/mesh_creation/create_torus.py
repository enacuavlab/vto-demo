#!/usr/bin/env python3

import pygalmesh
import numpy as np

n = 100  # Number of points in a ring
r_ring = 0.1  # Radius of the ring
r_torus = 0.75  # Radius of the torus

points = [
    [r_ring * np.cos(alpha) + r_torus, r_ring * np.sin(alpha)]
    for alpha in np.linspace(0, 2 * np.pi, n, endpoint=False)
]

p = pygalmesh.Polygon2D(points)
max_edge_size_at_feature_edges = 0.01
domain = pygalmesh.RingExtrude(p, max_edge_size_at_feature_edges)
domain = pygalmesh.Rotate(domain, [1.0, 0.0, 0.0], np.pi / 2)
domain = pygalmesh.Translate(domain, [0.0, 0.0, 2.0])

mesh = pygalmesh.generate_surface_mesh(
    domain,
    min_facet_angle=1.0,
    max_radius_surface_delaunay_ball=0.5,
    max_facet_distance=0.01,
    verbose=True,
)

mesh.write("obstacle.obj")
