# PGFlow3D

The code for the paper "Fluid Flow Vector Field based Guidance Algorithm for 3D Obstacle Avoidance in Cluttered Urban Environments" [pdf](https://)

The package is tested on **Ubuntu 22.04** and **Apple Silicon**.

## Getting Started

### Get the setup files

This repo is using submodules you need to copy this repo in order to obtain dependencies correctly.

```bash
git clone https://github.com/enac-drones/PGFlow3D.git --recursive
```

### Installation

You can install the python package using `pip`

```bash
cd PGFlow3D # Change the directory to PGFlow3D source files
pip install . # Install using pip
```

### Usage

#### PGFlow3D Standalone

A quick start of PGFlow3D without any additional dependencies is provided in the `examples` directory.

```bash
cd examples #Change current directory to examples
python3 mesh_creation/create_torus.py  # Create a torus mesh
python3 basic_torus_2_vehicle.py # Start a simulation with two drone
```

Note that PGFlow3D does not provide any vehicle dynamics or visualization future.

For visualization of the vehicle paths and obstacle, the scientific visualization software [Paraview](https://www.paraview.org/) can be used.

#### PGFlow3D and dronesim

dronesim is a simulation framework based on pyBullet and gym-pybullet-drones. For more details please check [dronesim](https://github.com/enac-drones/dronesim).

After getting dronesim installed can easily run a dronesim instance with the example provided in `examples` directory

```bash
cd examples #Change current directory to examples
python3 mesh_creation/create_torus.py  # Create a torus mesh
python3 dronesim_torus_2_vehicle.py # Start a dronesim simulation with two drones
```
